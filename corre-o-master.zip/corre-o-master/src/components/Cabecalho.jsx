export default function Cabecalho(){
    return(
        <header>
            <img src="se.jpg" alt="" />
        </header>
    )
    
}