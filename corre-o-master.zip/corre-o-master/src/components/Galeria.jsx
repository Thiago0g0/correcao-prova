export default function Galeria(){
    return(
        <div className="galeria">
            <img src="1.jpeg" alt=""/>
            <img src="1.jpeg" alt=""/>
            <img src="1.jpeg" alt=""/>
            <img src="1.jpeg" alt=""/>
            <img src="1.jpeg" alt=""/>
            <img src="1.jpeg" alt=""/>
        </div>
    )

}