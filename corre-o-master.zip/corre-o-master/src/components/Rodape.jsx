export default function Rodape(){
    return(
        <footer>
            <p>Kalil - 3B</p>
        </footer>
    )
        

}